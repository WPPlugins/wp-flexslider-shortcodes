(function ($) {
    'use strict';

    $(document).ready(function () {
       /* Hier kommt Code rein*/
    });
})(jQuery);
